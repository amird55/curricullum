﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Teachers
    {
        private string name;
        private Comment AvailbleDays;                                  
        private List<Course> courses;
        
        public Teachers(string name, List<Course> courses) 
        { 

            this.name = name;
            this.AvailbleDays = new Comment();
            this.courses = courses;
        }

        public string GetName()
        {
            return this.name;
        }

        public int[,] GetAvailbleDays()
        {
            return this.AvailbleDays.getScedual();
        }

        public List<Course> Getcourses()
        {
            return this.courses;
        }

        public List<string> CoursesNames(List<Course> courss)
        {
            List<string> coursesNames = new List<string>();
            foreach (Course c in courss)
            {
                coursesNames.Add(c.GetcName());
            }
            return coursesNames;
        }
        public bool IsTeaching(List<Course> courses)
        {
            List<string> courss = CoursesNames(courses);
            foreach (string n in courss)
            {
                if (n == name)
                    return true;
            }
            return false;
        }
    }
}