﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Comment
    {
        private int[,] scedual;
        public Comment()
        {
            scedual = new int[5, 6];
            for (int i = 0; i < scedual.GetLength(0); i++)
            {
                for (int j = 0; j < scedual.GetLength(1); j++)
                {
                    scedual[i, j] = 1;
                }
            }
        }

        public void cantCome(int day, int hour)
        {
            this.scedual[day, hour] = 2;
        }

        public void preferToCome(int day, int hour)
        {
            this.scedual[day, hour] = 0;
        }

        public void defualtCome(int day, int hour)
        {
            this.scedual[day, hour] = 1;
        }

        public int[,] getScedual()
        {
            return this.scedual;
        }

        public void printScedual()
        {
            for (int i = 0; i < this.scedual.GetLength(0); i++)
            {
                Console.Write("[");

                for (int j = 0; j < this.scedual.GetLength(1); j++)
                {
                    Console.Write(this.scedual[i, j] + ", ");
                }
                Console.WriteLine("]");

            }
        }
    }


}
