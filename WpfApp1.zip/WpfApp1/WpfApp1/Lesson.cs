﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Lesson
    {
        private string name;
        private string time;
        private string day;

        public Lesson(string Name, string Time, string Day)
        {
            this.name = Name;
            this.time = Time;
            this.day = Day;
        }

        public string getName()
        {
            return this.name;
        }

        public string getTime()
        {
            return this.time;
        }
        public string getDay()
        {
            return this.day;
        }

        public void setName(string Name)
        {
            this.name = Name;
        }

        public void setTime(string Time)
        {
            this.time = Time;
        }

        public void setDay(string Day)
        {
            this.day = Day;
        }

        public override string ToString()
        {
            return "The course name is " + this.name + " its starts in " + this.time + " in " + this.day;
        }
    }

   
}
