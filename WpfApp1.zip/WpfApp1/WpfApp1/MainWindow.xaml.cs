﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        String testID = "1111";
        String testPass = "aaaa";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login(object sender, RoutedEventArgs e)
        {
            if(IDTB.Text.Equals(testID) && PassTB.Text.Equals(testPass))
            {
                if(ItemSelector.Text.Equals("Student"))
                {
                    NavigationWindow navWIN = new NavigationWindow();
                    navWIN.Content = new MainPage();
                    navWIN.Show();
                    this.Close();
                }

                if(ItemSelector.Text.Equals("Teacher"))
                {
                    NavigationWindow navWIN = new NavigationWindow();
                    navWIN.Content = new Teacher();
                    navWIN.Show();
                    this.Close();
                }
               
            }
        }
    }
}
