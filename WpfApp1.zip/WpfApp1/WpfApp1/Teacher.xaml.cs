﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.Json;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Teacher.xaml
    /// </summary>
    public partial class Teacher : Page
    {
        public Teacher()
        {
            InitializeComponent();
        }

        private void Login(object sender, RoutedEventArgs e)
        {
            string ID = sender.ToString().Substring(32);

            

            dynamic MyControl = this.FindName(ID + "BT");

            if(MyControl.Background == Brushes.Yellow)
            {
                MyControl.Background = Brushes.LightGreen;
            }

            else if (MyControl.Background == Brushes.LightGreen)
            {
                MyControl.Background = Brushes.Red;
            }

            else
            {
                MyControl.Background = Brushes.Yellow;
                Console.WriteLine(MyControl.Background.GetType());
            }



        }

        private void submitScedual(object sender, RoutedEventArgs e)
        {
            Comment Scedual = new Comment();
            


            //sunday
            if(SundayFirstBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(0,0);
            }

            else if(SundayFirstBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(0, 0);
            }

            else
            {
                Scedual.cantCome(0, 0);
            }

            if (SundaySecondBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(0, 1);
            }

            else if (SundaySecondBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(0, 1);
            }

            else
            {
                Scedual.cantCome(0, 1);
            }

            if (SundayTheirdBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(0, 2);
            }

            else if (SundayTheirdBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(0, 2);
            }

            else
            {
                Scedual.cantCome(0, 2);
            }

            if (SundayFourBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(0, 4);
            }

            else if (SundayFourBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(0, 4);
            }

            else
            {
                Scedual.cantCome(0, 4);
            }

            if (SundayFiveBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(0, 5);
            }

            else if (SundayFiveBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(0, 5);
            }

            else
            {
                Scedual.cantCome(0, 5);
            }
            //sunday


            //monday
            if (MondayFirstBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(1, 0);
            }

            else if (MondayFirstBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(1, 0);
            }

            else
            {
                Scedual.cantCome(1, 0);
            }

            if (MondaySecondBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(1, 1);
            }

            else if (MondaySecondBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(1, 1);
            }

            else
            {
                Scedual.cantCome(1, 1);
            }

            if (MondayTheirdBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(1, 2);
            }

            else if (MondayTheirdBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(1, 2);
            }

            else
            {
                Scedual.cantCome(1, 2);
            }

            if (MondayFourBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(1, 4);
            }

            else if (MondayFourBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(1, 4);
            }

            else
            {
                Scedual.cantCome(1, 4);
            }

            if (MondayFiveBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(1, 5);
            }

            else if (MondayFiveBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(1, 5);
            }

            else
            {
                Scedual.cantCome(1, 5);
            }
            //monday

            //Tuesday
            if (TuesdayFirstBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(2, 0);
            }

            else if (TuesdayFirstBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(2, 0);
            }

            else
            {
                Scedual.cantCome(2, 0);
            }

            if (TuesdaySecondBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(2, 1);
            }

            else if (TuesdaySecondBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(2, 1);
            }

            else
            {
                Scedual.cantCome(2, 1);
            }

            if (TuesdayTheirdBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(2, 2);
            }

            else if (TuesdayTheirdBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(2, 2);
            }

            else
            {
                Scedual.cantCome(2, 2);
            }

            if (TuesdayFourBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(2, 4);
            }

            else if (TuesdayFourBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(2, 4);
            }

            else
            {
                Scedual.cantCome(2, 4);
            }

            if (TuesdayFiveBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(2, 5);
            }

            else if (TuesdayFiveBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(2, 5);
            }

            else
            {
                Scedual.cantCome(2, 5);
            }
            //Tuesday

            //Wednesday
            if (WednesdayFirstBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(3, 0);
            }

            else if (WednesdayFirstBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(3, 0);
            }

            else
            {
                Scedual.cantCome(3, 0);
            }

            if (WednesdaySecondBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(3, 1);
            }

            else if (WednesdaySecondBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(3, 1);
            }

            else
            {
                Scedual.cantCome(3, 1);
            }

            if (WednesdayTheirdBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(3, 2);
            }

            else if (WednesdayTheirdBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(3, 2);
            }

            else
            {
                Scedual.cantCome(3, 2);
            }

            if (WednesdayFourBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(3, 4);
            }

            else if (WednesdayFourBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(3, 4);
            }

            else
            {
                Scedual.cantCome(3, 4);
            }

            if (WednesdayFiveBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(3, 5);
            }

            else if (WednesdayFiveBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(3, 5);
            }

            else
            {
                Scedual.cantCome(3, 5);
            }
            //Wednesday

            //Thursday
            if (ThursdayFirstBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(4, 0);
            }

            else if (ThursdayFirstBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(4, 0);
            }

            else
            {
                Scedual.cantCome(4, 0);
            }

            if (ThursdaySecondBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(4, 1);
            }

            else if (ThursdaySecondBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(4, 1);
            }

            else
            {
                Scedual.cantCome(4, 1);
            }

            if (ThursdayTheirdBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(4, 2);
            }

            else if (ThursdayTheirdBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(4, 2);
            }

            else
            {
                Scedual.cantCome(4, 2);
            }

            if (ThursdayFourBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(4, 4);
            }

            else if (ThursdayFourBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(4, 4);
            }

            else
            {
                Scedual.cantCome(4, 4);
            }

            if (ThursdayFiveBT.Background == Brushes.Yellow)
            {
                Scedual.defualtCome(4, 5);
            }

            else if (ThursdayFiveBT.Background == Brushes.LightGreen)
            {
                Scedual.preferToCome(4, 5);
            }

            else
            {
                Scedual.cantCome(4, 5);
            }
            //Thursday

            Scedual.printScedual();

            var Newscedual = arrToJson.ConvertArr(Scedual.getScedual());
            var lishay = new Test(Newscedual);

            string jsonString = JsonSerializer.Serialize(lishay);
            string fileN = "Scedual";
            string filename = $@"C:\tmp\{fileN}.json";
            File.WriteAllText(filename, jsonString);
            Console.WriteLine(File.ReadAllText(filename));

        }
    }
}
