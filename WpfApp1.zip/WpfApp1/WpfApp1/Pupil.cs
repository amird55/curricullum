﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Pupil
    {
        private string firstName;
        private string lastName;
        private int id;
        private int age;

        private bool isLastYear;


        /*public Pupil()
        {
            this.firstName = dfgdf;
            this.lastName = dfgdfg;
            this.id = 0;
            this.age = 0:
            this.isLastYear = true;
        }*/

        public Pupil(string fName, string lName, int id, int age, bool isLastYear)
        {
            this.firstName = fName;
            this.lastName = lName;
            this.id = id;
            this.age = age;

            this.isLastYear = isLastYear;
        }

        public Pupil(Pupil p)
        {
            this.firstName = p.firstName;
            this.lastName = p.lastName;
            this.id = p.id;
            this.age = p.age;

            this.isLastYear = p.isLastYear;
        }

        //to string - hadpasa
        public string toString()
        {
            return "firstName = " + this.firstName + "" +
                "" + "lastName = " + this.lastName;
        }



        //getters & Setters

        //First Name
        public string getFirstName()
        {
            return this.firstName;
        }
        public void setFirstName(string name)
        {
            this.firstName = name;
        }

        //Last Name
        public string getLastName()
        {
            return this.lastName;
        }
        public void setLastName(string name)
        {
            this.lastName = name;
        }

        //ID
        public int getId()
        {
            return this.id;
        }
        public void setId(int id)
        {
            this.id = id;
        }

        //Age 
        public int getAge()
        {
            return this.age;
        }
        public void setAge(int value)
        {
            this.age = value;
        }

        //Is Last Year
        public bool getIsLastYear()
        {
            return this.isLastYear;
        }
        public void setIsLastYear(bool isLastYear)
        {
            this.isLastYear = isLastYear;
        }
    }
}

